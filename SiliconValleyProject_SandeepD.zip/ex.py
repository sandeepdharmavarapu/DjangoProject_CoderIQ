import json
with open('cache.json', 'rt') as file:
    print(json.load(file))