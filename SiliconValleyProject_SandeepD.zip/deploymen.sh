zip -r deployment.zip *
